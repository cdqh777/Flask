from django.apps import AppConfig


class PruebaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'prueba'
