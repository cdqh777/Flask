from django import forms

class ClienteForm(forms.Form):
    nombre = forms.CharField(max_length=100, label='Nombre')
    correo = forms.EmailField(label='Correo electrónico')
    año_nacimiento = forms.IntegerField(
        min_value=1900, 
        max_value=2025, 
        label='Año de Nacimiento'
    )